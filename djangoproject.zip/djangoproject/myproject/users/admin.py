from django.contrib import admin
from .models import AddUser
# Register your models here.
admin.site.register(AddUser)
